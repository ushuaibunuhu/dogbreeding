
const loadArranges = () => {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:8080/arranges", false);
    xhttp.send();

    const arranges = JSON.parse(xhttp.responseText);

    for (let arrange of arranges) {
        const x = `
            ${arrange.id} ${arrange.name}

                         ${arrange.phone}
                        ${arrange.place}
                        ${arrange.note}

                        <hr>

                        <button type="button" class="btn btn-danger">Delete</button>
                        
                    </div>
                </div>
            </div>
        `

        document.getElementById('maza').innerHTML = document.getElementById('maza').innerHTML + x;
    }
}

loadArranges();