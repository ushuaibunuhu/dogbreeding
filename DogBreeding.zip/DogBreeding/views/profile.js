
const loadProfile = () => {
    const xhttp = new XMLHttpRequest();
                       
    xhttp.open("GET", "http://localhost:8080/profiles", false);
    xhttp.send();

    const profiles = JSON.parse(xhttp.responseText);

    for (let profile of profiles) {
        const x = `
     
     
      <div class="flex-item"> <figure>
     <img style="float: left; margin: 0px 15px 15px 0px;" src="assets/images/one.jpg" width="100" />Name: ${profile.name}<br>
      Gender: ${profile.gender}<br>
       Birth Date: ${profile.dob} <br>
        Decrease Date:${profile.height}<br>
       <button> <a href="/arrange">Arrange</a></button>
       
      </figure>
      </div>
                     <hr>

                        <button type="button" class="btn btn-danger">Delete</button>
                        
                    </div>
                </div>
            </div>
        `

        document.getElementById('profile').innerHTML = document.getElementById('profile1').innerHTML + x;
    }
}

loadProfile();