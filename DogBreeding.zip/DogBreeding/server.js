if  (process.env.NODE_ENV !== 'production') {
    require('dotenv').config()
}

const express =  require('express')
const app = express()
var mysql = require('mysql')
var bodyParser = require('body-parser')
const bcrypt = require('bcryptjs')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
const cors = require('cors');



const initializePassport = require('./passport-config.js')
initializePassport(
    passport, 
    email => users.find( user => user.email === email),
    id => users.find(user => user.id === id)
)


const users = []
let profiles = []
let arranges = []

app.use(cors());

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: false}))
app.use(flash())
app.use(session({
    secret: process.env.SESSION_SECRET, 
    resave: false,
    saveUninitialized: false
}))

app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

app.get('/', (req, res) => {
    res.render('index.ejs')
})

app.get('/profile', (req, res) => {
    res.render('profile.ejs')
})
app.get('/profiles', (req, res) => {
    res.json(profiles);
});

app.get('/arrange', (req, res) => {
    res.render('arrange.ejs')
});

app.get('/arrange-list', (req, res) => {
    res.render('arrange-list.ejs')
});

app.get('/', (req, res) => {
    res.render('profile.js')
});

app.get('/arranges', (req, res) => {
    res.json(arranges);
});
app.post('/arrange', async (req, res) => {
    try{
        arranges.push({
            id: Date.now().toString(),
            name: req.body.name,
            phone: req.body.phone,
            place: req.body.place,
            note: req.body.note

        })
        res.send('arrange is added to the database');
    } catch {
        res.redirect('/arrange')
    }
    console.log(arranges)
})

app.get('/bitches', (req, res) => {
    res.render('bitches.ejs')
})

app.get('/dashboard', checkAuthenticated, (req, res) => {
    res.render('dashboard.ejs', { name: req.user.name})
})

app.get('/login', checkNotAuthenticated, (req, res) => {
    res.render('login.ejs')
})
 
app.post('/login', checkNotAuthenticated,  passport.authenticate( 'local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}))
 
app.get('/pofile-creation', (req, res) => {
    res.render('pofile-creation.ejs')
})

app.post('/pofile-creation', async (req, res) => {
    try{
        profiles.push({
            id: Date.now().toString(),
            name: req.body.name,
            dname: req.body.dname,
            cname: req.body.cname,
            prefex: req.body.prefex,
            breed: req.body.breed,
            gender: req.body.gender,
            dob: req.body.dob,
            ddob: req.body.ddob,
            coat: req.body.coat,
            marking: req.body.marking,
            size: req.body.size,
            height: req.body.height,
            weight: req.body.weight,
            hips: req.body.hips,
            eye: req.body.eye,
            ear: req.body.ear

        })
        res.redirect('/dashboard')
    } catch {
        res.redirect('/pofile-creation')
    }
    console.log(profiles)
})

app.get('/register', checkNotAuthenticated, (req, res) => {
    res.render('register.ejs')
})

app.post('/register', checkNotAuthenticated, async (req, res) => {
    try{
        const hashedPassword = await bcrypt.hash(req.body.password, 10)
        users.push({
            id: Date.now().toString(),
            name: req.body.name,
            email: req.body.email,
            password: hashedPassword
        })
        res.redirect('/login')
    } catch {
        res.redirect('/register')
    }
    console.log(users)
})

app.delete('/logout', (req, res) => {
    req.logOut()
    res.redirect('/login')
})

function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next()
    }

    res.redirect('/login')
}

function checkNotAuthenticated(req, res, next){
    if (req.isAuthenticated()){
       return res.redirect('/')
    }
   return next()
}





app.listen(8080)